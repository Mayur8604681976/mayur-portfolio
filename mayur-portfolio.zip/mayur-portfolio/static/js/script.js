/**
 * script.js — The Data Dimension | Mayur Pandey Portfolio
 * Vanilla JavaScript — no external dependencies.
 */

"use strict";

/* ================================================================
   1. NAVBAR — scroll state + mobile toggle + active section
================================================================ */
(function initNavbar() {
  const navbar    = document.getElementById("navbar");
  const toggle    = document.getElementById("nav-toggle");
  const menu      = document.getElementById("nav-menu");
  const navLinks  = document.querySelectorAll(".nav-link[data-section]");

  if (!navbar) return;

  // Scroll state
  function onScroll() {
    navbar.classList.toggle("scrolled", window.scrollY > 40);
    highlightActiveSection();
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  // Mobile toggle
  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      menu.classList.toggle("open", !expanded);
      document.body.style.overflow = expanded ? "" : "hidden";
    });

    // Close on nav-link click (mobile)
    menu.querySelectorAll(".nav-link").forEach(function (link) {
      link.addEventListener("click", function () {
        toggle.setAttribute("aria-expanded", "false");
        menu.classList.remove("open");
        document.body.style.overflow = "";
      });
    });

    // Close on outside click
    document.addEventListener("click", function (e) {
      if (menu.classList.contains("open") && !navbar.contains(e.target)) {
        toggle.setAttribute("aria-expanded", "false");
        menu.classList.remove("open");
        document.body.style.overflow = "";
      }
    });

    // Escape key
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && menu.classList.contains("open")) {
        toggle.setAttribute("aria-expanded", "false");
        menu.classList.remove("open");
        document.body.style.overflow = "";
        toggle.focus();
      }
    });
  }

  // Highlight active nav link based on scroll position
  function highlightActiveSection() {
    const sections = document.querySelectorAll("section[id]");
    let currentId = "";
    sections.forEach(function (sec) {
      const top = sec.getBoundingClientRect().top;
      if (top <= 120) currentId = sec.id;
    });
    navLinks.forEach(function (link) {
      const section = link.getAttribute("data-section");
      link.classList.toggle("active", section === currentId);
    });
  }
})();


/* ================================================================
   2. HERO CANVAS — animated data-point network
================================================================ */
(function initHeroCanvas() {
  const canvas = document.getElementById("heroCanvas");
  if (!canvas) return;
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

  const ctx = canvas.getContext("2d");
  let W, H, nodes, animId;

  function resize() {
    W = canvas.offsetWidth;
    H = canvas.offsetHeight;
    canvas.width  = W;
    canvas.height = H;
  }

  function randomBetween(a, b) { return a + Math.random() * (b - a); }

  function initNodes() {
    nodes = [];
    const count = Math.min(22, Math.floor((W * H) / 14000));
    for (let i = 0; i < count; i++) {
      nodes.push({
        x:  randomBetween(0, W),
        y:  randomBetween(0, H),
        vx: randomBetween(-0.25, 0.25),
        vy: randomBetween(-0.25, 0.25),
        r:  randomBetween(2, 4),
        color: Math.random() > 0.5 ? "#22D3EE" : "#8B5CF6",
        alpha: randomBetween(0.3, 0.7),
      });
    }
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // Draw connections
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 110) {
          ctx.beginPath();
          ctx.strokeStyle = `rgba(34,211,238,${0.15 * (1 - dist / 110)})`;
          ctx.lineWidth = 0.8;
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.stroke();
        }
      }
    }

    // Draw nodes
    nodes.forEach(function (n) {
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      ctx.fillStyle = n.color;
      ctx.globalAlpha = n.alpha;
      ctx.fill();
      ctx.globalAlpha = 1;

      // Move
      n.x += n.vx;
      n.y += n.vy;
      if (n.x < 0 || n.x > W) n.vx *= -1;
      if (n.y < 0 || n.y > H) n.vy *= -1;
    });

    animId = requestAnimationFrame(draw);
  }

  let resizeTimer;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      resize();
      initNodes();
    }, 200);
  });

  resize();
  initNodes();
  draw();

  // Pause when tab hidden
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
      cancelAnimationFrame(animId);
    } else {
      draw();
    }
  });
})();


/* ================================================================
   3. SCROLL ANIMATIONS (Intersection Observer)
================================================================ */
(function initScrollAnimations() {
  if (!("IntersectionObserver" in window)) {
    // Fallback: show everything
    document.querySelectorAll("[data-animate]").forEach(function (el) {
      el.classList.add("visible");
    });
    return;
  }

  const obs = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

  document.querySelectorAll("[data-animate]").forEach(function (el) {
    obs.observe(el);
  });
})();


/* ================================================================
   4. SKILLS TABS
================================================================ */
(function initSkillTabs() {
  const tabs   = document.querySelectorAll(".skill-tab");
  const panels = document.querySelectorAll(".skill-panel");
  if (!tabs.length) return;

  tabs.forEach(function (tab) {
    tab.addEventListener("click", function () {
      const category = tab.getAttribute("data-category");

      tabs.forEach(function (t) {
        t.classList.remove("active");
        t.setAttribute("aria-selected", "false");
      });
      panels.forEach(function (p) { p.classList.remove("active"); });

      tab.classList.add("active");
      tab.setAttribute("aria-selected", "true");

      const target = document.getElementById("tab-" + category);
      if (target) target.classList.add("active");
    });

    // Keyboard support
    tab.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        tab.click();
      }
    });
  });
})();


/* ================================================================
   5. PROJECT FILTERS
================================================================ */
(function initProjectFilters() {
  const buttons = document.querySelectorAll(".filter-btn");
  const grid    = document.getElementById("projects-grid");
  if (!buttons.length || !grid) return;

  const cards = grid.querySelectorAll(".project-card");

  buttons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      const filter = btn.getAttribute("data-filter");

      buttons.forEach(function (b) { b.classList.remove("active"); });
      btn.classList.add("active");

      cards.forEach(function (card) {
        const cat = card.getAttribute("data-category");
        if (filter === "all" || cat === filter) {
          card.classList.remove("hidden");
        } else {
          card.classList.add("hidden");
        }
      });
    });
  });
})();


/* ================================================================
   6. WORKFLOW STEPS — expand on click/hover
================================================================ */
(function initWorkflow() {
  const steps = document.querySelectorAll(".workflow-step");
  if (!steps.length) return;

  steps.forEach(function (step) {
    step.addEventListener("click", function () {
      const isActive = step.classList.contains("active");
      steps.forEach(function (s) {
        s.classList.remove("active");
        s.setAttribute("aria-expanded", "false");
      });
      if (!isActive) {
        step.classList.add("active");
        step.setAttribute("aria-expanded", "true");
      }
    });

    step.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        step.click();
      }
    });
  });
})();


/* ================================================================
   7. SMOOTH SCROLL for anchor links
================================================================ */
(function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener("click", function (e) {
      const targetId = link.getAttribute("href").slice(1);
      const target   = document.getElementById(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
        // Update URL without page jump
        history.pushState(null, "", "#" + targetId);
      }
    });
  });
})();


/* ================================================================
   9. FOOTER YEAR (also set inline, but added here for robustness)
================================================================ */
(function initFooterYear() {
  const el = document.getElementById("footer-year");
  if (el) el.textContent = new Date().getFullYear();
})();
